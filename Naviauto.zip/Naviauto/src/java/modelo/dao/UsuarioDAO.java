/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo.dao;

import bd.Conexion;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 *
 * @author javie
 */
public class UsuarioDAO {

    private Connection conexion;

    public UsuarioDAO() {
        this.conexion = new Conexion().getConexion();
    }

    /*
    *
    * METHODS
    *
    **/
    //Función para comprobar el tipo de usuario en cuestión
    public String tipoUsuario(String usuario) {
        //Variable para almacenar el tipo de usuario
        String tipoUsuario = "";

        try {
            //Consulta
            PreparedStatement ps = conexion.prepareStatement("SELECT tipoUsuario from usuarios where usuario like '" + usuario + "';");
            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                tipoUsuario = rs.getString("tipoUsuario");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return tipoUsuario;
    }

    //Función para comprobar las credenciales del usuario
    public boolean comprobarCredenciales(String usuario, String password) {

        //Variable para almacenar si el usuario/contraseña es correcta
        boolean esCorrecto = false;

        try {
            //Consulta
            PreparedStatement ps = conexion.prepareStatement("SELECT id_usuario from usuarios "
                    + "where usuario like '" + usuario + "' and password like '" + password + "';");

            ResultSet resultSet = ps.executeQuery();

            while (resultSet.next()) {
                esCorrecto = true;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return esCorrecto;
    }
    
    //Comprobar si ya hay un usuario con ese email
    public boolean comprobarEmail(String email) {
        boolean usuarioExiste = false;

        try {
            PreparedStatement ps = conexion.prepareStatement("SELECT * FROM `usuarios` WHERE email = '" + email + "';");
            ResultSet resultSet = ps.executeQuery();

            if (resultSet.next()) {
                usuarioExiste = true;
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return usuarioExiste;
    }
    
    //Función para añadir un nuevo usuario
    public boolean addUsuario(String password, String nombre, String apellido, String email, String dni, String tipoUsuario) {
        boolean usuarioAdded = false;

        try {
            //Consulta
            PreparedStatement ps = conexion.prepareStatement("INSERT into Usuarios (dni, usuario, password, nombre, apellido, email, tipoUsuario)"
                    + "VALUES('" + dni + "','" + password + "','" + nombre + "','" + apellido + "','" + email + "','" + tipoUsuario + "');");

            if (!comprobarEmail(email)) {
                int row = ps.executeUpdate();
                usuarioAdded = true;
            }
        } catch (SQLException e) { 
            e.printStackTrace();
        }

        return usuarioAdded;
    }
}

/** ******************************************
 *
 * USUARIO DAO
 *
 */
package modelo.dao;

import bd.Conexion;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 *
 * @author javie
 */
public class UsuarioDAO {

    //Atributo conexion
    private Connection conexion;

    /**
     * ****************************************************
     *
     * CONSTRUCTOR
     *
     *
     */
    public UsuarioDAO() {
        this.conexion = new Conexion().getConexion();
    }

    /**
     * ****************************************************
     *
     * METODOS PÚBLICOS
     *
     *
     */
    //Función para comprobar el tipo de usuario en cuestión
    public String tipoUsuario(String correo) {
        //Variable para almacenar el tipo de usuario
        String tipoUsuario = "";

        try {
            //Consulta
            PreparedStatement ps = conexion.prepareStatement("SELECT tipoUsuario from usuarios where correo like '" + correo + "';");
            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                tipoUsuario = rs.getString("tipoUsuario");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return tipoUsuario;
    }

    //Función para comprobar las credenciales del usuario
    public boolean comprobarCredenciales(String correo, String password) {

        //Variable para almacenar si el usuario/contraseña es correcta
        boolean esCorrecto = false;

        try {
            //Consulta
            PreparedStatement ps = conexion.prepareStatement("SELECT * from correo "
                    + "where correo like '" + correo + "' and password like '" + password + "';");

            ResultSet resultSet = ps.executeQuery();

            while (resultSet.next()) {
                esCorrecto = true;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return esCorrecto;
    }

    //Comprobar si ya hay un usuario con ese email
    public boolean comprobarDNI(String dni) {
        boolean dniExiste = false;

        try {
            PreparedStatement ps = conexion.prepareStatement("SELECT * FROM usuarios WHERE dni = '" + dni + "';");
            ResultSet resultSet = ps.executeQuery();

            if (resultSet.next()) {
                dniExiste = true;
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        System.out.println("dnidndindi:" + dniExiste);

        return dniExiste;
    }

    //Comprobar si ya hay un usuario con ese email
    public boolean comprobarEmail(String email) {
        boolean correoExiste = false;

        try {
            PreparedStatement ps = conexion.prepareStatement("SELECT * FROM usuarios WHERE email = '" + email + "';");
            ResultSet resultSet = ps.executeQuery();

            if (resultSet.next()) {
                correoExiste = true;
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        System.out.println("coooreoeoreo:" + correoExiste);

        return correoExiste;
    }

    //Comprobar si ya hay un usuario con ese email
    public boolean comprobarTLF(String tlf) {
        boolean telefonoExiste = false;

        try {
            PreparedStatement ps = conexion.prepareStatement("SELECT * FROM usuarios WHERE telefono = '" + tlf + "';");
            ResultSet resultSet = ps.executeQuery();

            if (resultSet.next()) {
                telefonoExiste = true;
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return telefonoExiste;
    }

    //Función para añadir un nuevo usuario
    public boolean addUsuario(String dni, String telefono, String correo, String password, String nombre, String apellido, String tipoUsuario) {
        boolean usuarioAdded = false;

        try {
            //Consulta
            PreparedStatement ps = conexion.prepareStatement("INSERT into Usuarios (dni, telefono, email, password, nombre, apellido, tipoUsuario)"
                    + "VALUES('" + dni + "',"+telefono+",'" + correo + "','" + password + "','" + nombre + "','" + apellido + "','" + tipoUsuario + "');");

            int executeUpdate = ps.executeUpdate();
            usuarioAdded = true;

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return usuarioAdded;
    }
}

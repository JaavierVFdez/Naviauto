/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo.dao;

import bd.Conexion;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import modelo.entidad.Producto;

/**
 *
 * @author javie
 */
public class ProductoDAO {

    private Connection conexion;

    public ProductoDAO() {
        this.conexion = new Conexion().getConexion();
    }

    /**
     * ********************************
     *
     * PUBLIC METHODS
     *
     */
    
    //Función para mostrar los productos existentes
    public List<Producto> getListaProducto() {
        List<Producto> productos = new ArrayList();

        try {
            PreparedStatement ps = conexion.prepareStatement("SELECT * from productos;");
            ResultSet resultSet = ps.executeQuery();

            int id_producto = 0;
            String nombre = "";
            String descripcion = "";
            String categoria = "";
            String url = "";
            double precio = 0.0;
            int stock = 0;

            while (resultSet.next()) {
                
                //Almacenamos los datos
                id_producto = resultSet.getInt("id_producto");
                nombre = resultSet.getString("nombre");
                descripcion = resultSet.getString("descripcion");
                categoria = resultSet.getString("categoria");
                url = resultSet.getString("url");
                precio = resultSet.getDouble("precio");
                stock = resultSet.getInt("stock");
                
                
                
                System.out.println(id_producto);
                System.out.println(nombre);
                System.out.println(descripcion);
                System.out.println(categoria);
                System.out.println(url);
                System.out.println(precio);
                System.out.println(stock);
                
                
                Producto producto = new Producto(id_producto, nombre, descripcion, categoria, url, precio, stock);
                productos.add(producto);
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return productos;
    }
}

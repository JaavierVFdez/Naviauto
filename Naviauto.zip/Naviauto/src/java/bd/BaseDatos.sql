CREATE DATABASE naviauto;

CREATE TABLE Usuarios( 
    dni VARCHAR(9) not null,
    telefono int,
    email VARCHAR(55) not null, 
    password VARCHAR(16) not null, 
    nombre VARCHAR(15) not null, 
    apellido VARCHAR(15) not null, 
    tipoUsuario VARCHAR(15) not null,
    direccion VARCHAR(25),  
    PRIMARY KEY (dni)
);

CREATE TABLE Vehiculos(
    matricula VARCHAR(8) not null,
    dni VARCHAR(15) not null,
    modelo VARCHAR(20) not null, 
    marca VARCHAR(15) not null,
    anyoVehiculo DATE not null,
    kilometrajeActual int not null,
    PRIMARY KEY (matricula),
    CONSTRAINT fk_dni FOREIGN KEY (dni) REFERENCES Usuarios(dni)
);


CREATE TABLE Productos(
    codigo_producto VARCHAR(15) not null,
    nombre VARCHAR(25) not null,
    descripcion VARCHAR(95) not null,
    precio float not null,
    stock int not null,
    PRIMARY KEY (codigo_producto)
);

CREATE TABLE Servicio(
    id_servicio int not null,
    nombre VARCHAR(25) not null,
    descripcion VARCHAR(254) not null,
    PRIMARY KEY (id_servicio)
);


CREATE TABLE Factura(
    codigo_factura int not null,
    dni VARCHAR(9) not null,
    descripcion VARCHAR (254) not null,
    fecha DATE not null,
    precio float not null,
    PRIMARY KEY (codigo_factura),
    CONSTRAINT fk_dni_cliente FOREIGN KEY (dni) REFERENCES Usuarios(dni)
);


CREATE TABLE Reparaciones(
    codigo_reparacion int not null,
    matricula VARCHAR(8) not null,
    descripcion VARCHAR(249),
    fechaEntrada DATE not null,
    fechaFinalizacion DATE,
    estado VARCHAR(25),
    precio float,
    PRIMARY KEY (codigo_reparacion),
    CONSTRAINT fk_matricula FOREIGN KEY (matricula) REFERENCES Vehiculos(matricula)
);


CREATE TABLE Piezas(
    codigo_pieza int,
    codigo_reparacion int,
    nombre VARCHAR(25),
    fabricante VARCHAR(25),
    precio float,
    PRIMARY KEY (codigo_pieza),
    CONSTRAINT fk_id_reperacion FOREIGN KEY (codigo_reparacion) REFERENCES Reparaciones(codigo_reparacion)
);
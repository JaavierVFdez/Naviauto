/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package controlador;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import modelo.dao.UsuarioDAO;

/**
 *
 * @author javie
 */
@WebServlet(name = "Register", urlPatterns = {"/Register"})
public class Register extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            
            
            //Inicializamos los parámtros
            String correo = request.getParameter("correo");
            int telefono = 0;
            
            if(request.getParameter("tlf") == null) {
                telefono = Integer.parseInt(request.getParameter("tlf"));
            }
            
            String password = request.getParameter("password");
            String nombre = request.getParameter("nombre");
            String apellido = request.getParameter("apellido");
            String tipoUsuario = "usuario";
            
            System.out.println(correo);
            System.out.println(telefono);
            System.out.println(password);
            System.out.println(nombre);
            System.out.println(apellido);

            //Booleanos para comprobar si los datos son válidos
            boolean emailCorrecto = false;
            boolean dniCorrecto = false;
            boolean telefonoCorrecto = false;
            boolean telefonoIntroducido = false;

            //Objeto
            UsuarioDAO usuarioDao = new UsuarioDAO();

            //Comprobamos si ya existe el correo
            if (!usuarioDao.comprobarEmail(correo)) {
                emailCorrecto = true;
            }
            if (telefono != 0) {
                telefonoIntroducido = true;
            }

            if (!telefonoIntroducido) {
                if (usuarioDao.comprobarTLF(telefono)) {
                    telefonoCorrecto = true;
                }
            }
            

            //Comprobamos si los datos son validos para crear el usuario
            if (emailCorrecto && dniCorrecto) {
                
                System.out.println("correcto1");

                //Comprobamos si el usuario ha introducido el numero de telefono (dato opcional)
                if (telefonoIntroducido) {
                    
                    System.out.println("correcto2");

                    //Comprobamos si el telefono es correcto
                    if (telefonoCorrecto) {
                        
                        System.out.println("correcto3");
                        
                        //Damos de alta al usuario
                        usuarioDao.addUsuario(telefono, correo, password, nombre, apellido, tipoUsuario);
                        request.setAttribute("error", "");
                        response.sendRedirect("login.jsp");
                        return;
                    }

                } else {

                    System.out.println("correcto4");
                    
                    //Damos de alta al usuario sin el telefono
                    usuarioDao.addUsuarioSinTelefono(correo, password, nombre, apellido, tipoUsuario);
                    request.setAttribute("error", "");
                    response.sendRedirect("login.jsp");
                    return;
                }
            }
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
